import type { StatusBarProps } from 'react-native';

export interface IStatusBarProps extends StatusBarProps {}
