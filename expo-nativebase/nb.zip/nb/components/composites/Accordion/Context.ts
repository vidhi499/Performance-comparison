import { createContext } from 'react';

export const AccordionContext = createContext({});

export const AccordionItemContext = createContext({});
