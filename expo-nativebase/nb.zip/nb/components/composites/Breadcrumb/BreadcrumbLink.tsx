import BreadcrumbLink from '../../primitives/Link';

export default BreadcrumbLink;
