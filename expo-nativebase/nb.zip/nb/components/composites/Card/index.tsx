import { default as Card } from './Card';
import type { ICardProps } from './types';

export default Card;
export type { ICardProps };
