import type { IBoxProps } from '../../primitives';

export interface ICardProps extends IBoxProps<ICardProps> {}
