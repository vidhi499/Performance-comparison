import { default as CircularProgress } from './CircularProgress';
export default CircularProgress;
