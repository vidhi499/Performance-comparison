// import React from 'react';
// import { Box } from '../../primitives';
// import getIndexedChildren from '../../../utils/getIndexedChildren';
// import type { IFabListProps } from './props';

// import { omitUndefined } from '../../../theme/tools/utils';

// const FabList = ({ children, ...props }: IFabListProps) => {
//   const newProps = omitUndefined(props);
//   return (
//     <Box position="absolute" {...newProps}>
//       {getIndexedChildren(children, 'FabItem', 0)}
//     </Box>
//   );
// };

// export default FabList;
