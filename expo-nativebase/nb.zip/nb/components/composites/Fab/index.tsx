export { default as Fab } from './Fab';
export type { IFabProps } from './types';
