import type { IBoxProps } from '../../primitives';
export type IKbdProps = IBoxProps<IKbdProps>;
