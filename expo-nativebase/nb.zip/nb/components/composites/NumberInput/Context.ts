import { createContext } from 'react';

export const NumberInputContext = createContext({});
