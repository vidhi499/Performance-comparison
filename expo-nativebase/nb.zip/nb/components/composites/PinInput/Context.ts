import { createContext } from 'react';

export const PinInputContext = createContext({});
