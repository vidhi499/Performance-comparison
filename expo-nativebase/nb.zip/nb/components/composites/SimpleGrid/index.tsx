export { default as SimpleGrid } from './SimpleGrid';
export type { ISimpleGridProps } from './types';
