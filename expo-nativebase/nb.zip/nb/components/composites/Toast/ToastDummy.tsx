// This component is just exported for the documentation purpose
import type { IToastProps } from './types';

export const Toast = (props: IToastProps) => {
  props; // no-op
};
