import type { IFlexProps } from './../../primitives/Flex/types';

export type IWrapProps = IFlexProps & {
  space?: number;
};
