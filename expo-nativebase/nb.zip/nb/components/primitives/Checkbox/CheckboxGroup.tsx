import React, { createContext, memo, forwardRef , useState, useMemo} from 'react';
import { useCheckboxGroupState } from '@react-stately/checkbox';
import { useCheckboxGroup } from '@react-native-aria/checkbox';
import { useFormControlContext } from '../../composites/FormControl';
import type { ICheckboxGroupProps, ICheckboxContext } from './types';
import Box from '../Box';
import { useHasResponsiveProps } from '../../../hooks/useHasResponsiveProps';

export const CheckboxGroupContext = createContext<ICheckboxContext | null>(
  null
);

const CheckboxWrapper = React.memo((props: any) => {
  return <Box alignItems="flex-start" {...props.groupProps} {...props} ref={props.ref}>
    {props.children}
  </Box>;
});
function CheckboxGroup(
  { size, colorScheme, ...props }: ICheckboxGroupProps,
  ref?: any
) {
  // const { children } = props;
  const state = useCheckboxGroupState(props);
  const { groupProps } = useCheckboxGroup(
    { 'aria-label': props.accessibilityLabel, ...props },
    state
  );
  const formControlContext = useFormControlContext();



  const contextValue = useMemo(() => {
    return {
      size,
      colorScheme,
      formControlContext,
      state,
    }
  }, [size, colorScheme, formControlContext, state]);

  const [propsState] = useState(props)


  //TODO: refactor for responsive prop
  if (useHasResponsiveProps({ ...props, size, colorScheme })) {
    return null;
  }

console.log("checkbox groupd")
  return (
    <CheckboxGroupContext.Provider
      value={contextValue}
    >
     <CheckboxWrapper  {...groupProps} {...propsState} ref={ref}/>
    </CheckboxGroupContext.Provider>
  );
}



export default memo(forwardRef(CheckboxGroup));
