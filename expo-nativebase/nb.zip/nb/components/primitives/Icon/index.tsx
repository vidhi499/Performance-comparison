export { default as Icon } from './Icon';
export { createIcon } from './createIcon';
export type { IIconProps } from './types';
