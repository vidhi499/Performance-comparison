export { Svg, G, Path, Polygon, Line, Circle, Rect } from 'react-native-svg';
