export { default as Pressable } from './Pressable';
export { IPressableProps } from './types';
