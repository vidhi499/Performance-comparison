import React from 'react';

export const SliderContext = React.createContext<any>({});
