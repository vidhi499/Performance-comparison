import type { IColorModeContextProps } from './../color-mode/types';

export type IHybridContextProps = {
  colorMode: IColorModeContextProps;
};
