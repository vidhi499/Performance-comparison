export { default as Factory } from './component';
export type { FactoryComponentProps } from './types';
