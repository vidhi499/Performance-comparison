// jest.mock('react-native/Libraries/Animated/src/NativeAnimatedHelper');
