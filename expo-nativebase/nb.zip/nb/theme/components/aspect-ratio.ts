const baseStyle = {};
const defaultProps = {
  ratio: 4 / 3,
};
export default {
  baseStyle,
  defaultProps,
};
