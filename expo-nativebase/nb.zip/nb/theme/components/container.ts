const baseStyle = {
  maxWidth: '80%',
};

export default {
  baseStyle,
};
