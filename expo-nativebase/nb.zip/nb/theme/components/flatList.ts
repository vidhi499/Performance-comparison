const baseStyle = {};
const defaultProps = {};
export default {
  baseStyle,
  defaultProps,
};
