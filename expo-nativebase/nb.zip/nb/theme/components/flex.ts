const defaultProps = { flexDirection: 'column' };
export default {
  defaultProps,
};
