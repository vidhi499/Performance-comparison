export default {
  baseStyle: {},
  defaultProps: {},
};
