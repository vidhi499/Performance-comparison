export const ariaAttr = (condition: boolean | undefined) =>
  condition ? true : undefined;
